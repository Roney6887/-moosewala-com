Moosewala Com. PWA prototype
Open index.html in Safari for a demo. For true Add to Home Screen/PWA installation and reliable offline use, host this folder on an HTTPS website, then open it in Safari and choose Share > Add to Home Screen.
Data is stored in the browser's local storage. Use Reports > Export Data for backup.
